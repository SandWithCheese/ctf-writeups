export interface LoginResponseDTO{
    accessToken : string
}