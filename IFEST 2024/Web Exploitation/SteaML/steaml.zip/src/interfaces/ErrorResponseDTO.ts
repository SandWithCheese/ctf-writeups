export interface ErrorResponseDTO {
    message : string[]
}