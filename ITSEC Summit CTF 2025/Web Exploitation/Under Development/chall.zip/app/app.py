from flask import request, Flask, Response, render_template_string, render_template, make_response, redirect, jsonify
from dotenv import load_dotenv
from urllib.parse import unquote, quote_plus
from functools import wraps
import bcrypt
import datetime
import pymysql
import os
import jwt

load_dotenv()
app = Flask(__name__)

JWT_SECRET_KEY = os.getenv('SECRET_KEY')
HIDDEN_INFO = os.getenv('HIDDEN_INFO')
MYSQL_HOST= os.getenv('MYSQL_HOST')
MYSQL_USER= os.getenv('MYSQL_USER')
MYSQL_PASSWORD= os.getenv('MYSQL_PASSWORD')
MYSQL_DATABASE= os.getenv('MYSQL_DATABASE')

def connection():
    return pymysql.connect(
        host=MYSQL_HOST,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DATABASE,
        cursorclass=pymysql.cursors.DictCursor
    )

def generateJWT(username, role):
    payload = {
        'username': username,
        'role': role,
        'iat': int(datetime.datetime.now().timestamp()),
        'exp': int((datetime.datetime.now() + datetime.timedelta(seconds=3600)).timestamp())
    }
    token = jwt.encode(payload, JWT_SECRET_KEY, algorithm="HS256")
    return token

def auth_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.cookies.get('user_access')
        if not token:
            return jsonify({"message": "Token missing"}), 401

        try:
            payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=["HS256"])
            request.user = payload
        except jwt.ExpiredSignatureError:
            return jsonify({"message": "Token expired"}), 401
        except jwt.InvalidTokenError:
            return jsonify({"message": "Invalid token"}), 401
        return f(*args, **kwargs)
    return decorated

@app.route("/")
def home():
    return render_template_string("<p>Hello this website is under development</p><p>But you can send your info to <a href=/send-message>here</a></p><p>But make sure you're login <a href=/login>here</a></p>")

@app.route("/send-message", methods=["GET", "POST"])
@auth_required
def sendMessage():
    if request.method == "GET":
        return render_template("send-message.html")

    try:
        data = request.get_json(force=True)
    except Exception as e:
        return make_response(jsonify({"error": "Invalid JSON", "details": str(e)}), 400)

    name = str(data.get('name') or '').strip().replace('\n', ' ')
    message = str(data.get('message') or '').strip().replace('\n', ' ')

    if not name and not message:
        return make_response(jsonify({"message": "we need your name and your message >:("}), 400)

    encoded_name = quote_plus(name)
    encoded_message = quote_plus(message)

    return redirect(f"/customer-message?name={encoded_name}&message={encoded_message}", code=303)


@app.route("/customer-message", methods=["GET"])
@auth_required
def getMessages():
    name = str(request.args.get('name', '')).strip().replace('\n', ' ')
    message = str(request.args.get('message', '')).strip().replace('\n', ' ')

    if not name or not message:
        return make_response("<p>at least give me your name or message</p>", 400)

    return render_template('customer-message.html', name=name, message=message)

@app.route("/guess-access", methods=['GET'])
@auth_required
def guessAccess():
    if not request.args.get('access_code'):
        return make_response("<p>Do you understand what is guess?</p>", 404)

    access_code = unquote(request.args.get('access_code'))

    if str(HIDDEN_INFO) == access_code:
        flag = os.getenv("FLAG") or "ITSEC{FAKE_FLAG}"
        return make_response(f"<h1>{flag}</h1>", 200)
    else:
        return make_response("<p>Nope Sar, dat's not da access code</p>", 404)

@app.route("/hidden-access", methods=["GET"])
@auth_required
def hiddenAccess():
    if request.user['role'] == 0 or not request.args.get('access_code'):
        return make_response("<p>Your access is nuh-uh</p>", 404)

    access_code = unquote(request.args.get('access_code'))
    
    if HIDDEN_INFO.startswith(access_code):
        return make_response("<p>Higher up will meet you soon</p>", 200)
    
    return make_response("<p>You'll get but nothing here</p>", 404)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "GET":
        return render_template("login.html")
    
    data = request.get_json(silent=True)
    if not data:
        return make_response(jsonify({"message": "Invalid or missing JSON payload"}), 400)

    username = data.get('username', '')
    password = data.get('password', '')

    if not isinstance(username, str) or not isinstance(password, str):
        return make_response(jsonify({"message": "Username and password must be strings"}), 400)
    
    username = username.strip()
    password = password.strip()

    if not username or not password:
        return make_response(jsonify({"message": "Username and password are required"}), 400)

    try:
        conn = connection()
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE name = %s", (username,))
            user = cursor.fetchone()
    except pymysql.MySQLError as e:
        return make_response(jsonify({"message": "Database error", "error": str(e)}), 500)
    finally:
        if 'conn' in locals():
            conn.close()

    if not user or not bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
        return make_response(jsonify({"message": "Invalid username or password"}), 401)

    token = generateJWT(username, user['role'])

    response = make_response(redirect("/send-message"), 303)
    response.set_cookie(
        "user_access",
        token,
        max_age=3600,
        path="/",
        httponly=True,
        samesite="Lax",
        secure=False
    )
    return response


@app.route("/register", methods=['GET', 'POST'])
def register():
    if request.method == "GET":
        return render_template("register.html")
    
    data = request.get_json(silent=True)
    if not data:
        return make_response(jsonify({"message": "Invalid or missing JSON payload"}), 400)
    
    username = data.get('username', '')
    password = data.get('password', '')

    if not isinstance(username, str) or not isinstance(password, str):
        return make_response(jsonify({"message": "Username and password must be strings"}), 400)
    
    username = username.strip()
    password = password.strip()
    
    if not username or not password:
        return make_response(jsonify({"message": "Username and password must be provided"}), 400)

    try:
        conn = connection()
        with conn.cursor() as cursor:
            cursor.execute("SELECT 1 FROM users WHERE name = %s", (username,))
            if cursor.fetchone():
                return make_response(jsonify({"message": "Username already exists"}), 409)
            
            hashed_pass = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode('utf-8')
            cursor.execute(
                "INSERT INTO users (name, password, role) VALUES (%s, %s, %s)",
                (username, hashed_pass, 0)
            )
            conn.commit()
        return make_response(redirect("/login"), 303)

    except pymysql.MySQLError as e:
        return make_response(jsonify({"message": "Database error", "error": str(e)}), 500)
    
    except Exception as e:
        return make_response(jsonify({"message": "Internal server error", "error": str(e)}), 500)
    
    finally:
        if 'conn' in locals():
            conn.close()
    
if __name__ == "__main__":
    app.run(host="0.0.0.0",port=5000)