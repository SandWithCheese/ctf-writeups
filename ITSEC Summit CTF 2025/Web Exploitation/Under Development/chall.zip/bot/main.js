import puppeteer from 'puppeteer'
import express from 'express'
import rateLimit from 'express-rate-limit'
import { generateJWT } from './jwtUtil.js'

const app = express()
app.use(express.static('static'))
app.use(express.json())
app.use(
    '/visit', rateLimit({
        windowMs: 4 * 60 * 1000,
        max: 5,
        message: { error: 'Too many requests, try again later' }
    })
)

const port = process.env.PORT || 5588
const APP_URL = process.env.APP_URL || 'http://app'
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function visit(url) {
    let browser = await puppeteer.launch({
        ignoreHTTPSErrors: true,
        acceptInsecureCerts: true,
        headless: true,
        args: [
            '--no-sandbox',
            '--disable-background-networking',
            '--disable-default-apps',
            '--disable-extensions',
            '--disable-gpu',
            '--disable-sync',
            '--disable-translate',
            '--metrics-recording-only',
            '--mute-audio',
            '--no-first-run',
            '--safebrowsing-disable-auto-update',
            '--disable-dev-shm-usage',
            '--incognito',
        ]
    })
    const cookie = generateJWT({username: "alamakjang", role:1})
    const ctx = await browser.createBrowserContext()
    const page = await ctx.newPage()
    console.log(`Visiting -> ${url}`)
    try {
        await page.setCookie({
			name: 'user_access',
			value: cookie,
			domain: new URL(APP_URL).hostname,
            httpOnly: true,
            sameSite: 'Lax'
		});
        await page.goto(url)
        await sleep(3*60*1000)
    } catch (err){
        console.log(err);
    } finally {
        await page.close()
        await ctx.close()
        console.log(`Done visiting -> ${url}`)
    }
}

app.post('/visit', async (req, res) => {
    let { url } = req.body;

    if (typeof url !== 'string' || !url) {
        return res.status(400).send({ error: "Invalid URL" });
    }

    try {
        const parsedUrl = new URL(url);

        if (!['http:', 'https:'].includes(parsedUrl.protocol)) {
            return res.status(400).send({ error: "URL must use http or https" });
        }

        console.log(`[*] Visiting URL -> ${url}`);
        visit(url);
        return res.sendStatus(200);

    } catch (e) {
        console.error(`[-] Error visiting URL -> ${url}: ${e.message}`);
        return res.status(400).send({ error: "Malformed URL" });
    }
});

app.listen(port, async () => {
    console.log(`[*] Listening on port ${port}`)
})