const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
require('dotenv').config();

const db = new sqlite3.Database('./database.db', (err) => {
  if (err) {
    console.error('Error opening database:', err.message);
  } else {
    console.log('Connected to SQLite database.');
    setupDatabase();
  }
});

async function setupDatabase() {
  try {
    const admin_pass = process.env.ADMIN_SECRET
    const admin_pass_enc = await bcrypt.hash(admin_pass, 10);

    console.log("Admin password:", admin_pass);

    db.run(`CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL
    );`, (err) => {
      if (err) {
        console.error('Error creating table:', err.message);
      } else {
        console.log('Users table created successfully.');

        db.run(`INSERT OR IGNORE INTO users (username, password) VALUES ('admin', ?)`, [admin_pass_enc], (err) => {
          if (err) {
            console.error('Error inserting admin user:', err.message);
          } else {
            console.log('Admin user created successfully.');
          }
        });
      }
    });
  } catch (error) {
    console.error('Error setting up database:', error);
  }
}

module.exports = db;
