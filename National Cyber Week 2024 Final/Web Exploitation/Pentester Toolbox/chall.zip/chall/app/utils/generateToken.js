const jwt = require('jsonwebtoken');
require('dotenv').config();
const JWT_SECRET = process.env.JWT_SECRET

function generateToken(user) {
  const payload = { username: user.username, user_id: user.id };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '1h' });
}

module.exports = { generateToken, JWT_SECRET };
