const redirect = (res, requestUrl = "", defaultUrl = "", host) => {
    try {
        if (requestUrl) {
            const url = new URL(requestUrl);
        
            // prevent cross site scripting & open redirect
            if (!url.protocol.toLowerCase().includes("javascript") && url.hostname === host) {
                res.header("Location", requestUrl);
                return res.status(302).send(`Redirecting to ${requestUrl}`);
            } else {
                return res.status(400).send("Invalid host");
            }
        }
    } catch (error) {
        console.log(error)
    }

    res.header("Location", defaultUrl);
    return res.status(302).send(`Redirecting to ${defaultUrl}`);
};

module.exports = redirect;
