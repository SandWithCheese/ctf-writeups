document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form");
    const resultDiv = document.getElementById("result");
  
    form.addEventListener("submit", async function (event) {
      event.preventDefault();
  
      // Get CSRF token and input value
      const csrfToken = document.querySelector('input[name="_csrf"]').value;
      const inputText = document.querySelector('textarea[name="input"]').value;
  
      // Create URL-encoded data
      const formData = new URLSearchParams();
      formData.append("input", inputText);
      formData.append("_csrf", csrfToken);
  
      try {
        // Send POST request to server
        const response = await fetch(form.action, {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: formData.toString(),
        });
  
        if (response.ok) {
          const data = await response.text(); // Expecting plain text response
          // Display result in the result div
          resultDiv.innerHTML = `<p class="alert alert-success">${data}</p>`;
        } else {
          resultDiv.innerHTML = `<p class="alert alert-danger">Error: Unable to process your request.</p>`;
        }
      } catch (error) {
        console.error("Error:", error);
        resultDiv.innerHTML = `<p class="alert alert-danger">An error occurred. Please try again later.</p>`;
      }
    });
  });
  