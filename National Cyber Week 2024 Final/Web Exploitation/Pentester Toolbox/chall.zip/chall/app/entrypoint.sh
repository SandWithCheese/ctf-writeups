#!/bin/bash

export admin_pass=$(xxd -u -l 16 -p /dev/urandom)

node /app/app.js