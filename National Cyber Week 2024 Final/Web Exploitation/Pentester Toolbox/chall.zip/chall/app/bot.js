const { firefox } = require('playwright');
const { generateToken } = require('./utils/generateToken');

const browser_options = {
    headless: true,
    args: [
        '--disable-dev-shm-usage',
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-gpu',
        '--no-gpu',
        '--disable-default-apps',
        '--disable-translate',
        '--disable-device-discovery-notifications',
        '--disable-software-rasterizer',
        '--disable-xss-auditor'
    ],
    ignoreHTTPSErrors: true
};
let token = generateToken({ username:"admin",id: 1});

function sleep(s) {
    return new Promise((resolve) => setTimeout(resolve, s));
}

async function visit(url){
	let context = null;
	let initBrowser = await firefox.launch(browser_options)
	context = await initBrowser.newContext();
	 try {
		const page = await context.newPage();
		await context.addCookies([{
			name: "authToken",
			httpOnly: false,
			value: token,
			url: 'http://localhost:3000'
		}]);
		await page.goto(url, {
			waitUntil: 'load',
			timeout: 10 * 1000
		});
		await sleep(5000);
		return true;
	} catch (e) {
		console.error(e);
		return false;
	} finally {
		await context.close();
		await initBrowser.close()
	}
};

module.exports = { visit };