const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../utils/database');
const { generateToken } = require('../utils/generateToken');
const redirect = require('../utils/redirect');
const csrfProtection = require('../middleware/csrfProtection');

const router = express.Router();

router.get('/register', csrfProtection, (req, res) => {
  res.render('register', { csrfToken: req.csrfToken() });
});

router.post('/register', csrfProtection, async (req, res) => {
  const { username, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashedPassword], (err) => {
    if (err) return res.status(400).send('Username already exists');
    redirect(res, req.query.next, '/auth/login', req.hostname);
  });
});

router.get('/login', csrfProtection, (req, res) => {
  res.render('login', { csrfToken: req.csrfToken() });
});

router.post('/login', csrfProtection, (req, res) => {
  const { username, password } = req.body;

  db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
    if (err || !user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).send('Invalid username or password');
    }
    const token = generateToken(user);
    res.cookie('authToken', token, { httpOnly: true });
    redirect(res, req.query.next, '/dashboard', req.hostname);
  });
});

router.get('/logout', (req, res) => {
    Object.keys(req.cookies).forEach((cookie) => {
      res.clearCookie(cookie);
    });
  
    redirect(res, req.query.next, '/', req.hostname);
  });

module.exports = router;
