const express = require('express');
const csrfProtection = require('../middleware/csrfProtection');
const authenticateToken = require('../middleware/authenticateToken');

const router = express.Router();

router.get('/', csrfProtection, (req, res) => {
  res.render('index', { csrfToken: req.csrfToken() });
});

router.get('/dashboard', authenticateToken, (req, res) => {
  res.render('dashboard', { user: req.user });
});

module.exports = router;
