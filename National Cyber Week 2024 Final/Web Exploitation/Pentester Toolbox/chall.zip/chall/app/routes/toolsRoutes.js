const express = require('express');
const path = require('path');
const { exec } = require('child_process');
const multerConfig = require('../utils/multerConfig');
const authenticateToken = require('../middleware/authenticateToken');
const csrfProtection = require('../middleware/csrfProtection');
const crypto = require('crypto');
const redirect = require('../utils/redirect');

const router = express.Router();

router.get('/b64encode', authenticateToken, csrfProtection, (req, res) => {
    res.render('b64encode', { csrfToken: req.csrfToken() });
  });
  
  router.post('/b64encode', authenticateToken, csrfProtection, (req, res) => {
    try {
      const { input } = req.body;
      const encoded = Buffer.from(input).toString('base64');
      return res.status(200).send(encoded);
    } catch (err) {
      console.error(err);
      return res.status(500).send('Something went wrong!');
    }
  });
  
  router.get('/b64decode', authenticateToken, csrfProtection, (req, res) => {
    res.render('b64decode', { csrfToken: req.csrfToken() });
  });
  
  router.post('/b64decode', authenticateToken, csrfProtection, (req, res) => {
    try {
      const { input } = req.body;
      const decoded = Buffer.from(input, 'base64').toString('utf-8');
      return res.status(200).send(decoded);
    } catch (err) {
      console.error(err);
      return res.status(500).send('Something went wrong!');
    }
  });
  
  module.exports = router;
  

router.get('/decompile', authenticateToken, csrfProtection, (req, res) => {

    if (!(req.user.user_id === 1)) {
        return res.status(403).send('Access denied');
    }

    res.render('decompile', { csrfToken: req.csrfToken() });
});

router.post('/decompile', multerConfig.single('file'), authenticateToken, csrfProtection, (req, res) => {
    if (!(req.user.user_id === 1)) {
        return res.status(403).send('Access denied');
    }
    
    const uniqueId = crypto.randomBytes(16).toString('hex');
    const outputDir = path.join(__dirname, '../decompiled', uniqueId);

    exec(`apktool d ./uploads/target.apk -o ${outputDir}`, (err) => {
        if (err) return res.status(500).send('Error during APK decompilation');
        redirect(res, `/results/${uniqueId}`, `/results/${uniqueId}`, req.hostname);
    });
});

module.exports = router;
