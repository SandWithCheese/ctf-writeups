const express = require('express');
const authenticateToken = require('../middleware/authenticateToken');
const router = express.Router();
const bot = require('../bot');
const rateLimit = require("express-rate-limit")

const urlRegex = "^http://localhost:3000/.*"

const limit = rateLimit({
    ...bot,
    handler: ((req, res, _next) => {
        const timeRemaining = Math.ceil((req.rateLimit.resetTime - Date.now()) / 1000)
        res.status(429).json({
            error: `Too many requests, please try again later after ${timeRemaining} seconds.`,
        });
    })
})


router.get('/report', async (req, res) => {
    res.render("bot", { name:"Admin" });
});


router.post("/report", limit, async (req, res) => {
    const { url } = req.body;
    if (!url) {
        return res.status(400).send({ error: "Url is missing." });
    }
    if (!RegExp(urlRegex).test(url)) {
        return res.status(422).send({ error: "URL din't match this regex format " + urlRegex })
    }
    if (await bot.visit(url)) {
        return res.send({ success: "Admin successfully visited the URL." });
    } else {
        return res.status(500).send({ error: "Admin failed to visit the URL." });
    }
});

// router.post('/report', async (req, res) => {
// 	const { content } = req.body;
// 	if(content){
// 		bot.visit(content);
// 		return res.send(response('Your complain is checked by admin'));
// 	}
// 	else{
// 		return res.status(403).send(response('Empty content cannot be checked'));
// 	}
// })

module.exports = router;