const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const { initDb } = require('./utils/database');
const redirect = require('./utils/redirect');
const serveIndex = require('serve-index');
require('dotenv').config();

const app = express();
const PORT = process.env.port || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use('/results', express.static(path.join(__dirname, 'decompiled')), serveIndex(path.join(__dirname, 'decompiled'), {'icons': true}))
app.use('/', require('./routes/indexRoutes'));
app.use('/auth', require('./routes/authRoutes'));
app.use('/tools', require('./routes/toolsRoutes'));
app.use('/bot', require('./routes/botRoutes'));

app.use((req, res) => {
  redirect(res, req.query.next, '/', req.hostname);
});

app.use((err, req, res, next) => {
  console.error("Internal Server Error:", err);
  res.status(500).send("Something went wrong! Please try again later.");
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
