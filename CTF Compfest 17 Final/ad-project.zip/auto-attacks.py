#!/usr/bin/env python3
"""
auto-attacks.py — Attack-Defense CTF orchestrator (tick-aware, per-target, no DB)

Features:
- Tick scheduling anchored to script start (configurable via .env)
- Per-enemy-service execution (reads /api/v2/services; falls back to enemy-ip.txt)
- Runs each chall's solver with --target/--team/--tick
- In-memory dedupe within a run (no persistent DB)
- Submission batching + exponential backoff for 429/5xx/network errors
- DRY_RUN mode for safe testing
"""
import os
import sys
import time
import json
import random
import logging
import subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from dotenv import load_dotenv

# --------------------------- Setup & Config ---------------------------

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("auto-attacks")

# Platform auth
CTF_API_HOST = os.getenv("CTF_API_HOST", "https://api.ctf-compfest.com")
TEAM_EMAIL = os.getenv("TEAM_EMAIL")
TEAM_PASSWORD = os.getenv("TEAM_PASSWORD")

AUTH_URL = f"{CTF_API_HOST}/api/v2/authenticate"
SERVICES_URL = f"{CTF_API_HOST}/api/v2/services"
SUBMIT_URL = f"{CTF_API_HOST}/api/v2/submit"

# Concurrency & batching
MAX_WORKERS = int(os.getenv("MAX_WORKERS", "8"))
SUBMIT_BATCH_SIZE = int(os.getenv("SUBMIT_BATCH_SIZE", "20"))
SUBMIT_DELAY_SECONDS = float(os.getenv("SUBMIT_DELAY_SECONDS", "1.0"))
DRY_RUN = os.getenv("DRY_RUN", "false").lower() in ("1", "true", "yes")

# Tick scheduling
TICK_SECONDS = float(os.getenv("TICK_SECONDS", "300"))
SCRIPT_START_TIME = float(os.getenv("SCRIPT_START_TIME", "0")) or time.time()
TICK_OFFSET_MS = float(os.getenv("TICK_OFFSET_MS", "0"))
TICK_JITTER_MS = float(os.getenv("TICK_JITTER_MS", "0"))
ALIGN_TO_TICK = os.getenv("ALIGN_TO_TICK", "true").lower() in ("1", "true", "yes")
RUN_NOW = os.getenv("RUN_NOW", "false").lower() in ("1", "true", "yes")

# Custom scheduling
SCHEDULE_TICK = os.getenv("SCHEDULE_TICK")
RUN_EVERY_TICKS = os.getenv("RUN_EVERY_TICKS")
if RUN_EVERY_TICKS:
    RUN_EVERY_TICKS = int(RUN_EVERY_TICKS)
MAX_RUNTIME_TICKS = os.getenv("MAX_RUNTIME_TICKS")
if MAX_RUNTIME_TICKS:
    MAX_RUNTIME_TICKS = int(MAX_RUNTIME_TICKS)

# Backoff knobs (optional; defaults are sensible)
SUBMIT_MAX_RETRIES = int(os.getenv("SUBMIT_MAX_RETRIES", "6"))
SUBMIT_BACKOFF_BASE = float(os.getenv("SUBMIT_BACKOFF_BASE", "0.5"))
SUBMIT_BACKOFF_FACTOR = float(os.getenv("SUBMIT_BACKOFF_FACTOR", "2.0"))
SUBMIT_JITTER_MS = float(os.getenv("SUBMIT_JITTER_MS", "150"))
SUBMIT_MAX_SLEEP = float(os.getenv("SUBMIT_MAX_SLEEP", "12.0"))
SUBMIT_RESPECT_RETRY_AFTER = os.getenv("SUBMIT_RESPECT_RETRY_AFTER", "true").lower() in ("1", "true", "yes")

# In-memory set to avoid resubmitting duplicates within the same run
# Key shape: (flag, challenge_id, team_id, tick)
SEEN_FLAGS = set()


# --------------------------- Tick helpers ---------------------------

def current_tick(now: float | None = None) -> int:
    now = now or time.time()
    elapsed = now - SCRIPT_START_TIME
    if elapsed < 0:
        elapsed = 0.0
    return int(elapsed // TICK_SECONDS)


def tick_start_time(tick: int) -> float:
    return SCRIPT_START_TIME + tick * TICK_SECONDS


def seconds_until_tick(target_tick: int, offset_ms: float = 0.0, jitter_ms: float = 0.0) -> float:
    now = time.time()
    jitter = (random.uniform(-1.0, 1.0) * jitter_ms) / 1000.0 if jitter_ms else 0.0
    offset = offset_ms / 1000.0
    target_time = tick_start_time(target_tick) + offset + jitter
    return max(0.0, target_time - now)


def wait_until_tick(target_tick: int, offset_ms: float = 0.0, jitter_ms: float = 0.0) -> None:
    sleep_s = seconds_until_tick(target_tick, offset_ms, jitter_ms)
    log.info(f"Waiting {sleep_s:.3f}s until tick {target_tick} (+{offset_ms}ms ±{jitter_ms}ms)")
    if sleep_s > 0:
        time.sleep(sleep_s)
    log.info(f"Starting run (approx tick {current_tick()})")


# --------------------------- API helpers ---------------------------

def authenticate() -> str | None:
    """Return JWT token or None."""
    if not TEAM_EMAIL or not TEAM_PASSWORD:
        log.error("TEAM_EMAIL/TEAM_PASSWORD not set in .env")
        return None
    try:
        r = requests.post(AUTH_URL, json={"email": TEAM_EMAIL, "password": TEAM_PASSWORD}, timeout=10)
        if r.status_code == 200:
            token = r.json().get("data")
            if token:
                return token
        log.error("Auth failed %s: %s", r.status_code, r.text)
    except Exception:
        log.exception("Auth error")
    return None


def fetch_services(jwt: str | None) -> dict:
    """
    Try to fetch mapping of services for this tick.
    Expected example shape:
      { "<challenge_id>": { "<team_id>": ["host:port", ...], ... }, ... }
    If API unavailable or schema differs, we'll fall back to local enemy-ip.txt.
    """
    if not jwt:
        return {}
    try:
        headers = {"Authentication": f"Bearer {jwt}"}
        r = requests.get(SERVICES_URL, headers=headers, timeout=10)
        r.raise_for_status()
        data = r.json().get("data", {})
        if isinstance(data, dict):
            return data
    except Exception:
        log.debug("fetch_services() failed; using local enemy-ip.txt where available", exc_info=True)
    return {}


def submit_flags(jwt: str | None, flags: list[str]) -> dict:
    """
    Submit a batch of flags with exponential backoff.
    Retries on: 429, 502, 503, 504, and network exceptions.
    Honors Retry-After when present (if SUBMIT_RESPECT_RETRY_AFTER=true).
    """
    if not flags:
        return {}

    if DRY_RUN:
        log.info("DRY_RUN: would submit %d flags", len(flags))
        return {"dry_run": True, "submitted": flags}

    headers = {"Authentication": f"Bearer {jwt}"} if jwt else {}
    payload = {"flags": flags}

    attempt = 0
    while True:
        attempt += 1
        try:
            r = requests.post(SUBMIT_URL, headers=headers, json=payload, timeout=10)
            status = r.status_code

            if status < 400:
                try:
                    return r.json()
                except Exception:
                    return {"status_code": status, "text": r.text}

            # Retryable statuses
            if status in (429, 502, 503, 504):
                if attempt > SUBMIT_MAX_RETRIES:
                    log.warning("Submit failed after %d attempts (status %s)", attempt - 1, status)
                    try:
                        return r.json()
                    except Exception:
                        return {"status_code": status, "text": r.text, "error": "max_retries_exceeded"}

                # Compute wait
                wait = None
                if SUBMIT_RESPECT_RETRY_AFTER:
                    ra = r.headers.get("Retry-After")
                    if ra:
                        try:
                            wait = min(float(ra), SUBMIT_MAX_SLEEP)
                        except Exception:
                            wait = None
                if wait is None:
                    wait = min(SUBMIT_BACKOFF_BASE * (SUBMIT_BACKOFF_FACTOR ** (attempt - 1)), SUBMIT_MAX_SLEEP)
                if SUBMIT_JITTER_MS:
                    wait = max(0.0, wait + (random.uniform(-1.0, 1.0) * SUBMIT_JITTER_MS) / 1000.0)

                log.info("Submit got %s; retrying in %.2fs (attempt %d/%d)", status, wait, attempt, SUBMIT_MAX_RETRIES)
                time.sleep(wait)
                continue

            # Non-retryable error
            try:
                return r.json()
            except Exception:
                return {"status_code": status, "text": r.text}

        except requests.RequestException as e:
            if attempt > SUBMIT_MAX_RETRIES:
                log.error("Network error after %d attempts: %s", attempt - 1, e)
                return {"error": str(e), "attempts": attempt - 1, "max_retries": SUBMIT_MAX_RETRIES}
            wait = min(SUBMIT_BACKOFF_BASE * (SUBMIT_BACKOFF_FACTOR ** (attempt - 1)), SUBMIT_MAX_SLEEP)
            if SUBMIT_JITTER_MS:
                wait = max(0.0, wait + (random.uniform(-1.0, 1.0) * SUBMIT_JITTER_MS) / 1000.0)
            log.info("Network error %s; retrying in %.2fs (attempt %d/%d)", type(e).__name__, wait, attempt, SUBMIT_MAX_RETRIES)
            time.sleep(wait)
            continue


# --------------------------- Solver execution ---------------------------

def discover_challenges(base: Path = Path(".")) -> list[Path]:
    return sorted([p for p in base.iterdir() if p.is_dir() and p.name.startswith("chall")])


def run_solver_for_target(chal_path: Path, target: str, team_id: str, tick: int) -> list[str]:
    """
    Run chal_path/solver.py with args:
      --target <host:port> --team <team_id> --tick <tick>
    Expect stdout: JSON list of flags. Falls back to scanning lines with { }.
    """
    solver = chal_path / "solver.py"
    if not solver.exists():
        log.debug("No solver for %s", chal_path)
        return []

    cmd = [sys.executable, str(solver), "--target", str(target), "--team", str(team_id), "--tick", str(tick)]
    env = os.environ.copy()
    env["CURRENT_TICK"] = str(tick)

    try:
        proc = subprocess.run(cmd, cwd=str(chal_path), capture_output=True, text=True, env=env, timeout=60)
        if proc.stderr:
            log.debug("%s stderr: %s", chal_path.name, proc.stderr.strip())
        out = proc.stdout.strip()
        if not out:
            return []
        try:
            parsed = json.loads(out)
            if isinstance(parsed, list):
                return [str(x) for x in parsed]
        except json.JSONDecodeError:
            flags = []
            for line in out.splitlines():
                line = line.strip()
                if "{" in line and "}" in line:
                    flags.append(line)
            return flags
    except Exception:
        log.exception("Solver error for %s (target %s)", chal_path.name, target)

    return []


# --------------------------- Main loop ---------------------------

def main() -> int:
    jwt = authenticate()
    if not jwt:
        log.warning("Proceeding without JWT; submissions will likely fail")

    chals = discover_challenges()
    if not chals:
        log.error("No challenge folders found (names starting with 'chall')")
        return 1
    log.info("Local challenges: %s", [c.name for c in chals])

    # Determine first scheduled tick
    now_tick = current_tick()
    if SCHEDULE_TICK:
        target_tick = int(SCHEDULE_TICK)
    elif RUN_NOW or not ALIGN_TO_TICK:
        target_tick = now_tick
    else:
        target_tick = now_tick + 1

    runs = 0
    start_tick = target_tick

    while True:
        wait_until_tick(target_tick, TICK_OFFSET_MS, TICK_JITTER_MS)

        # Fetch service mapping fresh each tick
        services_map = fetch_services(jwt)  # dict[challenge_id] -> dict[team_id] -> [host:port, ...]

        # Build tasks per target
        tasks: list[tuple[Path, str, str, str]] = []  # (chal_path, chal_id, team_id, hostport)
        for chal_path in chals:
            chal_id = chal_path.name
            if services_map and chal_id in services_map:
                entries = services_map.get(chal_id, {})
                # entries: {team_id: [host:port, ...]}
                for team_id, hosts in (entries.items() if isinstance(entries, dict) else []):
                    for host in (hosts if isinstance(hosts, (list, tuple)) else []):
                        tasks.append((chal_path, chal_id, str(team_id), str(host)))
            else:
                # Fallback: local enemy-ip.txt (first line host:port), unknown team
                ep = chal_path / "enemy-ip.txt"
                if ep.exists():
                    host = ep.read_text().strip().splitlines()[0].strip()
                    if host:
                        tasks.append((chal_path, chal_id, "unknown", host))

        log.info("Targets this tick (%d): %s", len(tasks), [(t[1], t[2], t[3]) for t in tasks][:5] + (["..."] if len(tasks) > 5 else []))

        # Run solvers concurrently per target
        discovered: list[tuple[str, str, str, int]] = []  # (flag, chal_id, team_id, tick)
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
            futs = {ex.submit(run_solver_for_target, t[0], t[3], t[2], target_tick): t for t in tasks}
            for fut in as_completed(futs):
                chal_path, chal_id, team_id, host = futs[fut]
                try:
                    flags = fut.result()
                except Exception:
                    flags = []
                for f in flags:
                    f = f.strip()
                    if not f:
                        continue
                    key = (f, chal_id, team_id, target_tick)
                    if key in SEEN_FLAGS:
                        continue
                    SEEN_FLAGS.add(key)
                    discovered.append((f, chal_id, team_id, target_tick))

        log.info("New candidate flags collected this tick: %d", len(discovered))

        # Submit flags in batches
        submit_results = []
        to_submit = [f for f, _, _, _ in discovered]
        for i in range(0, len(to_submit), SUBMIT_BATCH_SIZE):
            batch = to_submit[i:i + SUBMIT_BATCH_SIZE]
            res = submit_flags(jwt, batch)
            submit_results.append(res)
            time.sleep(SUBMIT_DELAY_SECONDS)

        # Persist a simple JSON summary for this tick
        summary = {
            "tick": target_tick,
            "targets": len(tasks),
            "found": len(discovered),
            "submitted_batches": len(submit_results),
            "results": submit_results,
        }
        Path("submit_results.json").write_text(json.dumps(summary, indent=2))

        runs += 1
        if RUN_EVERY_TICKS:
            target_tick += RUN_EVERY_TICKS
            if MAX_RUNTIME_TICKS is not None and (target_tick - start_tick) >= MAX_RUNTIME_TICKS:
                log.info("Reached MAX_RUNTIME_TICKS; exiting.")
                break
            continue
        else:
            log.info("Single-run complete; exiting.")
            break

    return 0


if __name__ == "__main__":
    sys.exit(main())
