#!/usr/bin/env python3
import argparse, os, json, socket, sys
parser = argparse.ArgumentParser()
parser.add_argument("--target", required=True)   # host:port
parser.add_argument("--team", required=True)
parser.add_argument("--tick", type=int, required=True)
args = parser.parse_args()

def exploit(host, port, team, tick):
    flags=[]
    try:
        with socket.create_connection((host, int(port)), timeout=6) as s:
            # Replace with real exploit payload for the challenge
            s.sendall(b"HELLO\n")
            data = s.recv(4096).decode(errors="ignore")
            for token in data.split():
                if "{" in token and "}" in token:
                    flags.append(token.strip())
    except Exception as e:
        # log to stderr (stdout must be JSON)
        print(f"[!] exploit error: {e}", file=sys.stderr)
    return flags

host, port = (args.target.split(":",1)+["80"])[:2]
flags = exploit(host, port, args.team, args.tick)



# HARUS PRINT(json.dumps(flags))
# Soalnya nanti dia return lewat stdout
print(json.dumps(flags))
