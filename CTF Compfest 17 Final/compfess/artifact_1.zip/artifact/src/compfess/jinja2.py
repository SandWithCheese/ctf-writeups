from jinja2 import Environment

def environment(**options):
    return Environment(**options)