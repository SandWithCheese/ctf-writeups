<?php
if (!isset($_GET['url'])) {
    die("Missing 'url' parameter.");
}

$url = $_GET['url'];

$parsed = parse_url($url);
if (in_array($parsed['scheme'], [
    'ftp',
    'ftps',
    'file',
    'php',
    'zlib',
    'data',
    'glob',
    'phar',
    'ssh2',
    'rar',
    'ogg',
    'expect',
    'zip'
])) {
    die("Invalid URL scheme.");
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo "cURL error: " . curl_error($ch);
} else {
    echo htmlspecialchars($response); 
}

curl_close($ch);
?>
