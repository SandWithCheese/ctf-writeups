from flask import Flask, request, render_template 
from jinja2 import Template
import waf

app = Flask(__name__)

@app.route("/")
def index():

    name = request.args.get("name", "")
    return render_template("index.html", name=name)

@app.route('/sub')
def sub():
    if request.args.get("name", "") :
        try :
            name = request.args.get("name", "").strip()    
            print(waf.sanitize_input(name))
            return Template(waf.sanitize_input(f"{name} has subscribed successfully")).render()
        except :
            return "error"

if __name__ == "__main__":
    app.run(debug=False,port=12345)
