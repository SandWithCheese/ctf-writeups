# SimerSimer

Description:

```
Chatbot SimerSimer merupakan teman chat lucu & rceh sekali.

URL : http://ctf.technofair11.com:1812
API : http://ctf.technofair11.com:1204

Author: necl
```
