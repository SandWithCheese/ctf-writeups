import random
from secret import flag

key = [random.randint(1, 256) for _ in range(len(flag))]

xorban = []
enc = []
for i, v in enumerate(key):
    k = 1
    for j in range(i, 0, -1):
        k ^= key[j]
    xorban.append(k)
    enc.append(flag[i] ^ v)

with open("output.txt", "w") as f:
    f.write(f"{xorban=}\n")
    f.write(f"{enc=}\n")