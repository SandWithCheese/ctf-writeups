var express = require("express");
var router = express.Router();

const flag = "FindITCTF{REDACTED}";

router.get("/", (req, res, next) => {
    res.render("index");
});

router.post("/", (req, res, next) => {
    const teks = req.body.teks;
    res.render("index", teks);
});

module.exports = router;
